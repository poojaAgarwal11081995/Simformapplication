export const PROFILE_PATH = "/profile";
export const LOGIN_PATH = "/login";