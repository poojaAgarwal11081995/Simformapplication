export const ItemStyle = {
    userSelect: "none",
    padding: 14,
    borderRadius:"5px",
    margin:" 0 0 8px 0",
    background: "#6feac5",
    
}
export const ListStyle ={
    background:"#fff",
    padding: 8,
    width: 250
}