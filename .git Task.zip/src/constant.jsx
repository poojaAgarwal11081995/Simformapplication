export const  USER_DETAILS="userDetails";
export const  PROFILE_DETAILS="profileDetails";

export const  LIST = [
    {
      id: '1',
      content: 'Javascript',  
    },
    {
      id: '2',
      content: 'Python',  
    },
    {
      id: '3',
      content: 'PHP',  
    },
    {
      id: '4',
      content: 'Java',  
    },
    {
      id: '5',
      content: 'C++',  
    },
  ];
export const REGEX ={
  numCheck : (myString) => /\d/.test(myString),
  
}