
import React  from 'react';
import './App.css';
import Routes from './component/routes/routes';
function App() {
  return (
     <Routes />
  );
}
export default App;
